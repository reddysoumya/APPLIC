import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { Book } from "./book";
import { Response } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';

@Injectable()
export class BookListService{
	constructor(private http:Http){ }
	public getJSON():Observable<Book[]>{
		return this.http.get('/app/booklist.json').map((response:Response)=><Book[]>response.json());
	}
}

